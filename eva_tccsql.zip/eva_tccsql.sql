-- --------------------------------------------------------
-- Servidor:                     127.0.0.1
-- Versão do servidor:           10.1.33-MariaDB - mariadb.org binary distribution
-- OS do Servidor:               Win32
-- HeidiSQL Versão:              9.5.0.5196
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- Copiando estrutura do banco de dados para eva
CREATE DATABASE IF NOT EXISTS `eva` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `eva`;

-- Copiando estrutura para tabela eva.arduino
CREATE TABLE IF NOT EXISTS `arduino` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `distancia` varchar(1000) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela eva.arduino: ~15 rows (aproximadamente)
/*!40000 ALTER TABLE `arduino` DISABLE KEYS */;
INSERT INTO `arduino` (`id`, `distancia`) VALUES
	(1, '300'),
	(2, '400'),
	(3, '500'),
	(4, '150'),
	(5, '100'),
	(6, '150'),
	(7, '100'),
	(8, '160'),
	(9, '140'),
	(10, '150'),
	(11, '150'),
	(12, '700'),
	(13, '800'),
	(14, '200'),
	(15, '100');
/*!40000 ALTER TABLE `arduino` ENABLE KEYS */;

-- Copiando estrutura para tabela eva.arduinodois
CREATE TABLE IF NOT EXISTS `arduinodois` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `distanciadois` int(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela eva.arduinodois: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `arduinodois` DISABLE KEYS */;
/*!40000 ALTER TABLE `arduinodois` ENABLE KEYS */;

-- Copiando estrutura para tabela eva.mob
CREATE TABLE IF NOT EXISTS `mob` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `saida` int(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela eva.mob: ~0 rows (aproximadamente)
/*!40000 ALTER TABLE `mob` DISABLE KEYS */;
/*!40000 ALTER TABLE `mob` ENABLE KEYS */;

-- Copiando estrutura para tabela eva.mobile
CREATE TABLE IF NOT EXISTS `mobile` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `entrada` int(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

-- Copiando dados para a tabela eva.mobile: ~11 rows (aproximadamente)
/*!40000 ALTER TABLE `mobile` DISABLE KEYS */;
INSERT INTO `mobile` (`id`, `entrada`) VALUES
	(1, 45),
	(2, 10),
	(3, 12),
	(4, 12),
	(5, 10),
	(6, 15),
	(7, 10),
	(8, 8),
	(9, 7),
	(10, 8),
	(11, 5);
/*!40000 ALTER TABLE `mobile` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
